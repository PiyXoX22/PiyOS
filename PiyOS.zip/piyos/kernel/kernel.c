#define VGA_ADDRESS 0xB8000
#define VGA_WIDTH 80

unsigned short* vga_buffer = (unsigned short*) VGA_ADDRESS;
int cursor_pos = 0;

unsigned short vga_entry(char ch, unsigned char color) {
	return (unsigned short) ch | (unsigned short) color << 8;
}

void vga_print(const char* str, unsigned char color) {
	for (int i = 0; str[i] != '\0'; i++) {
		if(str[i] == '\n') {
			cursor_pos += VGA_WIDTH - (cursor_pos % VGA_WIDTH);
		} else {
			vga_buffer[cursor_pos++] = vga_entry(str[i], color);
			}
		}
	}

void kernel_main() {
	vga_print("Welcome to PiyOS\n", 0x0F);
	vga_print("Kernel Sudah Diload", 0x0A);

	for(;;);
}
